import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
// import { AuthserviceService } from '../authservice.service';

@Component({
  selector: 'app-members',
  templateUrl: './members.component.html',
  styleUrls: ['./members.component.css']
})
export class MembersComponent implements OnInit {

  name:any;
  state:string='';

  // constructor(private auth:AuthserviceService, private router:Router){}
  
  // user:firebase.User;

  // ngOnInit() {
  //   this.auth.getUserState()
  //   .subscribe(user=>{
  //     this.user=user;
  //   })
  // }

  // login(){
  //   this.router.navigate(['/login']);
  // }

  // logout(){
  //   this.auth.logout();
  // }

  // register(){
  //   this.router.navigate(['/signup']);
  // }

  constructor(){}
  ngOnInit(){
    
  }
}

