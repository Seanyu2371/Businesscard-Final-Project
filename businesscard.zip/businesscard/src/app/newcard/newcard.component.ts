import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { modelcard } from '../cardset/modelcard';

@Component({
  selector: 'app-newcard',
  templateUrl: './newcard.component.html',
  styleUrls: ['./newcard.component.css']
})
export class NewcardComponent implements OnInit {

  // constructor(private _firestoreService: FireStoreService, private router : Router) { }
  constructor(){}

  form = new FormGroup({
    name: new FormControl(), 
    title: new FormControl(), 
    company: new FormControl(), 
    phone: new FormControl(),
    email: new FormControl(),
    web: new FormControl(),  
    address: new FormControl()
    });  

  ngOnInit() {
  }

  // onSubmit(){
  //   const businessCard = this.createBusinessCard();
  //   this._firestoreService.create(businessCard);
  //   this.router.navigate(['/businessCards']);
  //   this.form.reset();
  // }

  
  createBusinessCard(){
    var name=this.form.controls['name'].value;
    var email=this.form.controls['email'].value;
    var company=this.form.controls['company'].value;
    var title=this.form.controls['title'].value;
    var businessCard  = new modelcard(name,email,company,title);
  
    return businessCard;
  }

}
