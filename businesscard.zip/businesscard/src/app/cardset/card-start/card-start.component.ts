import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-card-start',
  templateUrl: './card-start.component.html',
  styleUrls: ['./card-start.component.css']
})
export class CardStartComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
