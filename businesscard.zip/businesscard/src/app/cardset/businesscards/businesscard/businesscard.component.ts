import { Component, OnInit, Input} from '@angular/core';
import { modelcard } from '../../modelcard';

@Component({
  selector: 'app-businesscard',
  templateUrl: './businesscard.component.html',
  styleUrls: ['./businesscard.component.css']
})
export class BusinesscardComponent implements OnInit {

  @Input() bscard:modelcard;
  @Input() index:number;

  ngOnInit() {
  }

}
