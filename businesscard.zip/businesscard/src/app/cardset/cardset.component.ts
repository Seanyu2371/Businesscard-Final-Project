import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cardset',
  templateUrl: './cardset.component.html',
  styleUrls: ['./cardset.component.css']
})
export class CardsetComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  
}
