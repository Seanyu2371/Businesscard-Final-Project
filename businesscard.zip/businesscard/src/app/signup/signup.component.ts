import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AngularFireAuth } from '@angular/fire/auth';
// import {  AuthserviceService } from '../authservice.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  autherror:any;

  // constructor(private auth:AuthserviceService){}

  // ngOnInit() {
  //   this.auth.eventAuthError$.subscribe( data => {
  //     this.autherror = data;
  //   })
  // }

  // createUser(frm){
  //   this.auth.createUser(frm.value);
  // }

  constructor(){}
  ngOnInit(){
    
  }
}

