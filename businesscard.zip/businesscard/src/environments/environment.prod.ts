export const environment = {
  production: true,
  firebase : {
    apiKey: "AIzaSyCwDWmYW7o1lyXqp-4_XOpucbwA2jnY0u0",
    authDomain: "businesscard-1d6c9.firebaseapp.com",
    databaseURL: "https://businesscard-1d6c9.firebaseio.com",
    projectId: "businesscard-1d6c9",
    storageBucket: "businesscard-1d6c9.appspot.com",
    messagingSenderId: "182909709648",
    appId: "1:182909709648:web:4e7f9f1070e9c162b0d055",
    measurementId: "G-XHPQCQY3KS"
  }
};
